# travelPath

Least time travel path project using djikstra algorithm
